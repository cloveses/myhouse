from user import *
from menu import *
from admin import *
print("--------------------")
print("      1.admin       ")
print("      2.user        ")
print("--------------------")
User_Key = input("请输入功能选项按回车：")
if User_Key == '1':
    a_main()
elif User_Key == '2':
    u_main()
