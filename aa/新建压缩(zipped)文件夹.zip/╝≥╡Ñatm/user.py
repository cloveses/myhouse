from menu import *
from admin import *
user={}
def login():
    uid=input("Enter your account number ")
    if user[uid]['state']==0:
        sign=0
        while sign<3:
            upassword=input("Enter your password")
            if uid in user and upassword==user[uid]['password']:
                return True
            else:
                print("Wrong password,try again")
            sign+=1
        if sign==3:
            lockaccount(user,uid)
            print("Your account has been locked,please contact the administrator to unlock it. ")
    else:
        print("Your account has been locked")
def check():
    print("account {0} balance {1}".format(uid,user[uid]['money']))
def withdraw():
    money=int(input("Please enter the amount of withdrawal "))
    if money%100!=0:
        print("The amount of withdrawal must be a multiple of 100")
    elif money>user[uid]['money']:
        print("Sorry, your credit is running low")
    else:
        user[uid]['money']-=money
        with open("user.data", "w+") as file:
            file.write(str(user))
            print(user)
        check()
def deposit():
    money=int(input("Please enter the amount of deposit"))
    if money%100!=0:
        print("Deposit amount must be multiple of 100 ")
    else:
        user[uid]['money']+=money
        with open("user.data", "w+") as file:
            file.write(str(user))
            print(user)
        check()
def transfer():
    acceptid=input("Please enter the target account for the transfer")
    money=int(input("Please enter the amount of transfer"))
    if money%100!=0:
        print("Transfer amount must be multiple of 100 ")
    elif money>user[uid]['money']:
        print("Sorry, your credit is running low")
    else:
        user[uid]['money']-=money
        user[acceptid]['money']+=money
        with open("user.data", "w+") as file:
            file.write(str(user))
            print(user)
        check()
def change():
    changeid=input("Please enter an account that needs to be modified")
    newpassword=input("Please enter a new password")
    check=map(lambda x:newpassword.count(x),list(set([x for x in newpassword])))
    while max(check) < 6:
        print("Too many password duplicate characters")
        newpassword=input("Please enter a new password")
        check=map(lambda x:newpassword.count(x),list(set([x for x in newpassword])))
    while not len(newpassword)==6:
        print("Password length must be six bits ")
        newpassword=input("Please enter a new password")
    confirm=input("Password qualified! Please confirm your password")
    while not newpassword==confirm:
        print("The new and confirmed passwords do not match. Try specifying and confirming your new password again")
        confirm=input("Please confirm your password")
    if newpassword==confirm:
        print("Successful password modification")
def umain():
    global user
    info_get=public_functions.default_infos()
    user_informations = info_get[0]
    print(user)
    if login():
        while True:
            print(Menu.umenu())
            User_Key = input()
            if User_Key == '1':
                check()
            elif User_Key == '2':
                withdraw()
            elif User_Key == '3':
                deposit()
            elif User_Key == '5':
                change()
            elif User_Key == '4':
                transfer()
            elif User_Key == '6':
                exit("\nGood Bye!")

        
