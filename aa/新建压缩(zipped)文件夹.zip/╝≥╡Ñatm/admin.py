from user import *
from menu import *
from function import *
import time
user={}
admin={}
state_=0
class Admin:
    __slots__=("account","password","level")
    def __init__(self,account,password,level):
        self.account=account
        self.password=password
        self.level=level
    def save_admin(self):
        admin={
            'account':self.account,
            'password':self.password,
            'level':self.level,
        }
        return admin
class User(Admin):
    __slots__=("account","password","level","money","state")
    def __init__(self,account,password,level,money,state):
        super().__init__(account,password,level)
        self.money=money
        self.state=state
    def save_user_information(self):
        user={
            'account': self.account,
            'password': self.password,
            'level': self.level,
            'money': self.money,
            'state': self.state
        }
        return user
def login():
    global state_
    aid=input("Please enter administrator account")
    apw=input("Please enter the administrator password ")
    if aid in admin and apw==admin[aid]['apw'] or aid=='a0001' and apw=='112233':
        return True
    else:
        print("Wrong account or password")
def adduser():
    account=input("Please enter a new user account")
    password=input("Please enter a new user password")
    level=1
    money=10000
    state=0
    get=user(account,password,level,money,state)
    with open("user.data", "w+") as file:
        file.write(str(user))
        print(user)
def lock():
    lockid=input("Please enter the user account to be locked")
    user[lockid]['state']=1
    with open("user.data", "w+") as file:
        file.write(str(user))
        print(user)
def unlock():
    unlockid=input("Please enter the user account to be unlocked")
    user[lockid]['state']=0
    with open("user.data", "w+") as file:
        file.write(str(user))
        print(user)
def a_main():
    global admin, user
    info_get = public_functions.default_infos()
    admin= info_get[1]
    user= info_get[0]
    print(admin, user)
    if login():
        while True:
            print(Menu.amenu())
            User_Key = input()
            if User_Key == '1':
                adduser()
            elif User_Key == '2':
                lock()
            elif User_Key == '3':
                unlock()
            elif User_Key == '4':
                User_Key_1 = input()
                if User_Key_1 == '1':
                    user_functions.print_informations_u(user)
                elif User_Key_1 == '2':
                    user_functions.search_infos(user)
            elif User_Key == '5':
                exit("\nGood Bye!")
