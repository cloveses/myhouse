class Menu:
    @staticmethod
    def umenu():
        menu='''
----------MENU----------
1.Check the balance
2.Withdraw money
3.Deposit money
4.Transfer accounts
5.Change Password
6.Exit
------------------------
'''
        return menu
    @staticmethod
    def amenu():
        menu='''
----------MENU----------
1.Add new account
2.Lock account
3.Unock account
4.Query user information
5.Exit
------------------------
'''
        return menu
