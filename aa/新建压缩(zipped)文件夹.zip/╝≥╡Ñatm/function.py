import os
import time
class public_functions:
    @staticmethod
    def default_infos():
        if os.path.exists("user_account.data") and os.path.exists("admin_account.data"):
            with open("user_account.data") as file1:
                user_informations = eval(file1.read())
            with open("admin_account.data") as file2:
                admin_informations = eval(file2.read())
            wait = '..........'
            print("Initialization is in progress. Just a moment, please")
            for i in wait:
                time.sleep(0.1)
                print(i, end=' ')
            if len(user_informations) > 0 and len(admin_informations) > 0:
                print("Succeed!")
                return user,admin
        else:
            return {}, {}
